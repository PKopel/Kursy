export class User {
  roles: any;
  courses: Array<any>;
  uid: string;
  email: string;
  firstName: string;
  lastName: string;
}
