export interface Filter {
  rating: Array<number>;
  semester: Array<number>;
  etcs: Array<number>;
  name: string;
}
