import {CourseFormElements} from './course-form-elements';

describe('CourseFormElements', () => {
  it('should create an instance', () => {
    expect(new CourseFormElements()).toBeTruthy();
  });
});
